# Plugin Development Guide

> :warning: This docs is WIP

## Architecture

![Vue Devtools Architectue](./assets/vue-devtools-architecture.svg)

